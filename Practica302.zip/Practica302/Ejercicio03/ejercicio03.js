"use strict";
import {cambiarColorAleatoriamente} from "../biblioteca/biblioteca.js";

//Llamada a la función de cambiar el color de fondo de un párrafo aleatorio a cada segundo.
setInterval(cambiarColorAleatoriamente, 1000);