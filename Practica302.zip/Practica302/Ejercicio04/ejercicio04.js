"use strict";
import {iniciarCarrusel} from "../biblioteca/biblioteca.js";

//Llamada a la función iniciarCarrusel.
iniciarCarrusel();